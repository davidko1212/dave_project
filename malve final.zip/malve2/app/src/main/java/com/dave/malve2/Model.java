package com.dave.malve2;



enum TYPE {
    CM,
    GRAM,
    HR,
    KILO,
    LENGTH,
    MET,
    MIL,
    MIN,
    MLG,
    SEC,
    TIME,
    WEIGHT

};

public class Model{
        private double num;
        private TYPE currntType;
        private double res;

        public Model(TYPE type){
            this.currntType = type;
        }
        public void setNum(double num){
            this.num =num;
        }
        public void setRes(double res) {
            this.res = res;
        }
        public void setCurrntType(TYPE currntType) {
            this.currntType = currntType;
        }
        public double getNum(){
        return this.num;
    }
        public double getRes(){
        return this.res;
    }
        public TYPE getCurrntType() {
        return this.currntType;
    }
        public double convertnum(double num,TYPE from,TYPE to){
            this.num = num;
            switch (currntType){
                case LENGTH:
                    if (from==TYPE.MIL && to==TYPE.CM)
                        this.res = this.num/10;
                    if (from==TYPE.CM && to==TYPE.MIL)
                        this.res = this.num*10;

                    if (from==TYPE.CM && to==TYPE.MET)
                        this.res = this.num/100;
                    if (from==TYPE.MET && to==TYPE.CM)
                        this.res = this.num*100;

                    if (from==TYPE.MIL && to==TYPE.MET)
                        this.res = this.num/1000;
                    if (from==TYPE.MET && to==TYPE.MIL)
                        this.res = this.num*1000;
                    break;
                case WEIGHT:
                    if (from==TYPE.KILO && to==TYPE.GRAM)
                        this.res = this.num*1000;
                    if (from==TYPE.GRAM && to==TYPE.KILO)
                        this.res = this.num/1000;

                    if (from==TYPE.GRAM && to==TYPE.MLG)
                        this.res = this.num*1000;
                    if (from==TYPE.MLG && to==TYPE.GRAM)
                        this.res = this.num/1000;

                    if (from==TYPE.KILO && to==TYPE.MLG)
                        this.res = this.num*1000000;
                    if (from==TYPE.MLG && to==TYPE.KILO)
                        this.res = this.num/1000000;
                    break;
                case TIME:
                    if(from==TYPE.HR && to==TYPE.MIN)
                        this.res = this.num*60;
                    if(from==TYPE.MIN && to==TYPE.HR)
                        this.res=this.num/60;

                    if(from==TYPE.MIN && to==TYPE.SEC)
                        this.res = this.num*60;
                    if(from==TYPE.SEC && to==TYPE.MIN)
                        this.res=this.num/60;

                    if(from==TYPE.HR && to==TYPE.SEC)
                        this.res = this.num*3600;
                    if(from==TYPE.SEC && to==TYPE.HR)
                        this.res=this.num/3600;
                    break;
            }
            return this.res;
        }



}

