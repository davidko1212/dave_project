package com.dave.malve2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button bt1,bt2,bt3,bt4,bt5,bt6;
    TextView tv1 , tv2, edittv;
    double x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initviews();
    }

    private void initviews() {
        bt1 = findViewById(R.id.bt1);
        bt2 = findViewById(R.id.bt2);
        bt3 = findViewById(R.id.bt3);
        bt4 = findViewById(R.id.bt4);
        bt5 = findViewById(R.id.bt5);
        bt6 = findViewById(R.id.bt6);
        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);
        edittv=findViewById(R.id.edittv);

    }

    public void multiplybyten(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x * 10;
            tv2.setText("result:" + x);
        }

    }


    public void input() {
        x= Double.parseDouble(edittv.getText().toString());

    }

    public void multiplybyhunderd(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x * 100;
            tv2.setText("result:" + x);
        }
    }

    public void multiplybythousnd(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x * 1000;
            tv2.setText("result:" + x);
        }
    }

    public void devidebyten(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x / 10;
            tv2.setText("result:" + x);
        }
    }

    public void devidebyhundred(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x / 100;
            tv2.setText("result:" + x);
        }
    }

    public void devidebythousnd(View view) {
        input();
        if(x==0) {
            tv2.setText("error");
        }
        else {
            x = x / 1000;
            tv2.setText("result:" + x);
        }
    }
}