package com.dave.malve2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    private Button btresult;
    private RadioButton rdFmil, rdFgr, rdFkil, rdTmil, rdTgr, rdTkil;
    private TextView tvWeightRes, result;
    private double num, res , x;
    private Model model;
    private EditText etWeightNum;
    private RadioGroup rdfrom, rdto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initviews();
        model = new Model(TYPE.WEIGHT);
    }

    private void initviews() {
        etWeightNum = findViewById(R.id.etweight);
        tvWeightRes = findViewById(R.id.tvweight);
        result = findViewById(R.id.tv2weight);
        rdFmil = findViewById(R.id.rdbtleft1);
        rdFgr = findViewById(R.id.rdbtleft2);
        rdFkil = findViewById(R.id.rdbtleft3);
        rdTmil = findViewById(R.id.rdbtright1);
        rdTgr = findViewById(R.id.rdbtright2);
        rdTkil = findViewById(R.id.rdbtright3);
        btresult = findViewById(R.id.btresult);
    }

    @Override
    public void onClick(View view) {
        if (view == btresult) {
            if (!etWeightNum.getText().toString().equals("")) {
                num = Double.parseDouble(etWeightNum.getText().toString());
                if (num > 0) {
                    if (rdFmil.isChecked() && rdTmil.isChecked()) {
                        Toast.makeText(this, "No, it makes no sense", Toast.LENGTH_SHORT).show();
                    }
                    if (rdFgr.isChecked() && rdTgr.isChecked()) {
                        Toast.makeText(this, "No, it makes no sense", Toast.LENGTH_SHORT).show();
                    }
                    if (rdFkil.isChecked() && rdTkil.isChecked()) {
                        Toast.makeText(this, "No, it makes no sense", Toast.LENGTH_SHORT).show();
                    }
                    if (rdFmil.isChecked() && rdTgr.isChecked()) {
                        res = num/1000;
                    }
                    if (rdFmil.isChecked() && rdTkil.isChecked()) {
                        res = num/1000000;
                    }
                    if (rdFgr.isChecked() && rdTmil.isChecked()) {
                        res = num*1000;
                    }
                    if (rdFgr.isChecked() && rdTkil.isChecked()) {
                        res = num/1000;
                    }
                    if (rdFkil.isChecked() && rdTmil.isChecked()) {
                        res = num*1000000;
                    }
                    if (rdFkil.isChecked() && rdTgr.isChecked()) {
                        res = num*1000;
                    }
                    result.setText("תוצאה: " + res);

                } else
                    Toast.makeText(this, "it makes no sense", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(this, "you didn't enter number", Toast.LENGTH_LONG).show();
        }

    }
}
